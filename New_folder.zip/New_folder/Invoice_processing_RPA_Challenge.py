import rpa as r
import pandas as pd
from datetime import datetime  
from datetime import timedelta
import openpyxl
import shutil
import smtplib
import email
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders


fromaddr = "reciver" #write the reciever details here
toaddr = "sender"  # write the sender details here


def date_picker(date,name):
    r.click("//input[@name ='"+name+"']")
    status = 1
    while status== 1:
        month_year = r.read("//th[@class='datepicker-switch']")
        if month_year == date.strftime("%B %Y"):
            a = str(date.strftime("%#d"))
            print(a)
            r.click("//td[@class='day' and text()='"+a+"']")
            status = 0
        else:
            r.click("//th[@class='next']")
    
    




d3 = datetime.now()
d4 = datetime.now() + timedelta(days=45)
print(d3)
print(d4.strftime("%m/%d/%Y"))
invoice_data = openpyxl.load_workbook('Invoice_Process_Details.xlsx')
invoice_excel = invoice_data.active

r.init(True,True)
r.url("http://challenge.rpabotsworld.com/auth/login")
r.keyboard('[alt][space]')
r.keyboard('[down]')
r.keyboard('[down]')
r.keyboard('[down]')
r.keyboard('[down]')
r.keyboard('[down]')
r.keyboard('[enter]')
r.type("//input[@name='username']","admin")
r.type("//input[@name='password']","rasmuslerdorf")
r.click("/html/body/div/div[2]/div/div[2]/form/div/input[3]")
login_success = r.exist("/html/body/div/section/header/header/a/span[2]")
if login_success == True:
    print("login is success..................")
    r.click("/html/body/div/section/aside/aside/section/ul[3]/li/a")
    r.click("/html/body/div/section/aside/aside/section/ul[3]/li/ul/li[2]/a")
    ##read the excel file and store in dataframe
    df = pd.read_excel('Invoice_Process_Details.xlsx')
    count = df.index
    for i in df.index:
        print(str(i+1)," transaction started...............")
        idx = int()
        Name = df['Customer Name'][i].replace(" ","").upper()
        print(Name)
        if Name == "SANJAYJAIN":
            idx = 98
        elif Name == "DEEPAKMISHRA":
            idx = 99
        elif Name == "RUCHISHARMA":
            idx = 100
        elif Name == "SONAMTIWARI":
            idx = 101
        elif Name == "VISHALGUPTA":
            idx = 102
        elif Name == "SANDEEPRAJ":
            idx = 103
        elif Name == "AMOLJANGID":
            idx = 104
        else:
            idx = 105
        
        r.select("/html/body/div/section/section/div/section/div[3]/form/div[2]/div/div[2]/div[1]/select",str(idx))
        r.type("//input[@name='invoice_no']",'[clear]'+"Inv-"+str(1000+i))
        date_picker(d3,"billing_date")
        date_picker(d4,"due_date")
        Status = df['Status'][i]
        if Status == 'UnPaid':
            Status = 'Unpaid'
        elif Status == 'OverDue':
            Status = 'Overdue'
        r.select('/html/body/div/section/section/div/section/div[3]/form/div[3]/div/div/div[4]/div/select',Status)
        r.type("//input[@name = 'product_description[]']",df['Products'][i])
        r.type("//input[@name = 'quantity[]']",'[clear]'+str(df['Quantity'][i]))
        r.type("//input[@name = 'price[]']",'[clear]'+str(df['Price'][i]))
        r.type("//input[@name = 'tax[]']",'[clear]'+'18')
        r.type("//input[@name = 'discount']",'[clear]'+str(df['Discount'][i]))
        r.click("//input[@value='Save Invoice']")
        total_amount = r.read("/html/body/div/section/section/div/section/div[2]/div[2]/div/div[2]/div/table/tbody/tr/td[3]")
        invoice_excel['G'+str(i+2)] = "Inv-"+str(1000+i)
        invoice_excel['H'+str(i+2)] = total_amount
        invoice_excel['I'+str(i+2)] = "Success"
        invoice_data.save('Invoice_Process_Details.xlsx')
        download_url = r.read("//a[@class='btn btn-primary']/@href")
        r.download(download_url,"pdf//Inv-"+str(1000+i)+".pdf")
        r.click("//a[@class='btn btn-danger']")
        r.wait(3)
        #r.click("//a[@class='btn btn-success']")
        print(str(i+1)," transaction is successfull.............")
        r.click("/html/body/div/section/aside/aside/section/ul[3]/li/ul/li[2]/a")

    print("logged out")
    r.click("/html/body/div/section/header/header/nav/div/ul/li/a")
    r.click("/html/body/div/section/header/header/nav/div/ul/li/ul/li[2]/div[1]/a")
    print("Closing browser.........................")
    r.close()
    print("zipping folder......................")
    shutil.make_archive("invoices_list", "zip", "pdf")
    print("sending email................")

    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Invoice_Details"
    body = "Hi Nived \n kindly check attachments \n Regards \n Nived N"
    msg.attach(MIMEText(body, 'plain'))
    filename_excel = "Invoice_Process_Details.xlsx"
    filename_zip = "invoices_list.zip"
    attachment_1 = open(filename_excel, "rb")
    attachment_2 = open(filename_zip,"rb")
    p1 = MIMEBase('application', 'octet-stream')
    p2 = MIMEBase('application', 'octet-stream')
    p1.set_payload((attachment_1).read())    
    p2.set_payload((attachment_2).read())
    encoders.encode_base64(p1)
    encoders.encode_base64(p2)
    p1.add_header('Content-Disposition',"attachment", filename=  "invoices_data.xlsx" )
    p2.add_header('Content-Disposition', "attachment", filename= "invoices_list.zip")
    msg.attach(p1)
    msg.attach(p2)
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login(fromaddr, "password")
    text = msg.as_string()
    s.sendmail(fromaddr, toaddr, text)
    s.quit()
    




        
        

        
        
        
        
        

else:
    print("login failed.....................")
    r.close()
