import rpa as r
import pandas as pd
from datetime import datetime  
from datetime import timedelta

d3 = datetime.now().strftime("%m/%d/%Y")
d4 = datetime.now() + timedelta(days=45)
print(d3)
print(d4.strftime("%m/%d/%Y"))

r.init(True,True)
r.url("http://challenge.rpabotsworld.com/auth/login")
r.type("//input[@name='username']","admin")
r.type("//input[@name='password']","rasmuslerdorf")
r.click("/html/body/div/div[2]/div/div[2]/form/div/input[3]")
login_success = r.exist("/html/body/div/section/header/header/a/span[2]")
if login_success == True:
    print("login is success..................")
    r.click("/html/body/div/section/aside/aside/section/ul[3]/li/a")
    r.click("/html/body/div/section/aside/aside/section/ul[3]/li/ul/li[2]/a")
    ##read the excel file and store in dataframe
    df = pd.read_excel('Invoice_Process_Details.xlsx')
    count = df.index
    for i in df.index:
        Name = df['Customer Name'][i].replace(" ","").upper()
        print(Name)
        r.wait(5)
        r.select("//*[@name='user_id']",Name)
        r.type("//input[@name='invoice_no']","Inv"+str(1000+i))
        r.type("/html/body/div[1]/section/section/div/section/div[3]/form/div[3]/div/div/div[2]/input",'[clear]'+d3)
        r.type("/html/body/div[1]/section/section/div/section/div[3]/form/div[3]/div/div/div[3]/input",'[clear]'+d4.strftime("%m/%d/%Y"))
        
        
        

else:
    print("login failed.....................")
